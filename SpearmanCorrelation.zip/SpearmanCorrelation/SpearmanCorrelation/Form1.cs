﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SpearmanCorrelation
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            string[] s1 = txtX.Text.Split(new char[] { ' ', '\t', '\n', '\r' },
                    StringSplitOptions.RemoveEmptyEntries);
            string[] s2 = txtY.Text.Split(new char[] { ' ', '\t', '\n', '\r' },
                StringSplitOptions.RemoveEmptyEntries);
            if(s1.Length!=s2.Length)
            {
                MessageBox.Show("Length of both arrays hould be same !");
                return;
            }
            int n = s1.Length;
            List<DataPoint> list = new List<DataPoint>(n);

            for (var i = 0; i < n; i++)
            {
                list.Add(new DataPoint() { X = double.Parse(s1[i]), Y = double.Parse(s2[i]) });
            }

            list.Sort(new myComparer("y"));
            for (var i = 0; i < n; i++)
            {
                list[i].RankByY = i + 1;
            }
            list.Sort(new myComparer("x"));
            for (var i = 0; i < n; i++)
            {
                list[i].RankByX = i + 1;
            }
            double sum = 0;
            txtResults.Text = string.Format("{0} \t {1} \t {2} \t {3} \t {4} \t {5}\r\n",
                "X","Y","Rank X","Rank Y","d","d^2");
            for (int i = 0; i < n; i++)
            {
                  txtResults.Text += string.Format("{0} \t {1} \t {2} \t {3} \t {4} \t {5}\r\n",
                  list[i].X, list[i].Y, list[i].RankByX, list[i].RankByY,
                  list[i].RankByX - list[i].RankByY, 
                  Math.Pow(list[i].RankByX - list[i].RankByY,2));
                sum += Math.Pow(list[i].RankByX - list[i].RankByY, 2);
            }
            double r = 1-6 * sum / (Math.Pow(n, 3) - n);
            txtResults.Text += string.Format("Sum d^2 = {0}\r\n",sum);
            txtResults.Text += string.Format("r = {0}\r\n", r);
        }

        
        private void btnPasteSampleData_Click(object sender, EventArgs e)
        {
            int[] x = { 24, 16, 10, 8, 18, 14, 13, 11, 9, 17 };
            int[] y = { 100, 22, 13, 14, 11, 10, 9, 12, 15, 8 };
            for (int i = 0; i < x.Length; i++)
            {
                txtX.Text += string.Format("{0}\r\n", x[i]);
                txtY.Text += string.Format("{0}\r\n", y[i]);
            }
        }
    }
    public class myComparer : IComparer<DataPoint>
    {
        string order;
        public myComparer(string order)
        {
            this.order = order;
        }
        public int Compare(DataPoint a, DataPoint b)
        {            
            if (order == "x")
            {
                if (a.X > b.X) return 1;
                if (a.X < b.X) return -1;
                return 0;
            } else           
            {
                if (a.Y > b.Y) return 1;
                if (a.Y < b.Y) return -1;
                return 0;
            }

        }
    }
    public class DataPoint
    {
        public double X, Y;
        public int RankByX, RankByY;
    }
    
}
